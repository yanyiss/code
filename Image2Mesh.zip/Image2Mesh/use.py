import os
import pymeshlab

targetlen=pymeshlab.PercentageValue(0.5)
iterations=100

ms=pymeshlab.MeshSet()
ms.load_new_mesh('meshdata/turtle.obj')
ms.meshing_isotropic_explicit_remeshing(targetlen=targetlen,iterations=iterations)
ms.save_current_mesh(file_name='/home/yanyisheshou/Program/Image2Mesh/bigmeshdata/turtle_big.obj')

