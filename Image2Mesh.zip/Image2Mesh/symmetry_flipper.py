import cv2
import os
import numpy as np
import triangle
import pymeshlab
import openmesh
import tool
import math

targetlen=pymeshlab.PercentageValue(1.0)
iterations=100
frac=0.5

def trans_and_rotate(point):
    size=int(point.shape[0]/2)
    point=point.reshape(size,2)
    center=point[0]*frac+point[-1]*(1-frac)
    point=point-center
    theta=math.atan2(point[0,1],point[0,0])
    
    pass

def construct_symmetry_mesh(mesh_dir,id0,id1):
    mesh=openmesh.read_trimesh(mesh_dir)
    hl_begin=0
    hl_end=0
    for vhl in mesh.voh(mesh.vertex_handle(id0)):
        if mesh.is_boundary(vhl):
            hl_begin=vhl
            break
    for vhl in mesh.voh(mesh.vertex_handle(id1)):
        if mesh.is_boundary(vhl):
            hl_end=vhl
            break
    hl_end=mesh.next_halfedge_handle(hl_end)

    hl_itr=hl_begin
    point=np.array([])
    while(hl_itr!=hl_end):
        pos=mesh.point(mesh.from_vertex_handle(hl_itr))
        point=np.append(point,pos[0])
        point=np.append(point,pos[1])
        hl_itr=mesh.next_halfedge_handle(hl_itr)

    

    tri=tool.dt(point.reshape(int(point.shape[0]/2)[::-1,:],2))
    m=tool.mesh(tri)
    ms=pymeshlab.MeshSet()
    ms.add_mesh(m,"cube_mesh")
    ms.meshing_isotropic_explicit_remeshing(targetlen=targetlen,iterations=iterations)
    vertices=ms.current_mesh().vertex_matrix()
    faces=ms.current_mesh().face_matrix()


