import cv2
import os
import numpy as np
import triangle
import pymeshlab
import openmesh
import cv2
import os
import numpy as np
import triangle
import pymeshlab

tarp_size=4.0
tarp_height=2.45
tarp_ori=[0,0,-1]

def dt(polygon):
    size=polygon.shape[0]
    segments=np.zeros_like(polygon).astype(np.int32)
    segments[:,0]=range(size)
    segments[:,1]=range(1,size+1)
    segments[size-1,1]=0
    tri=triangle.triangulate({'vertices': polygon,'segments': segments}, 'peq30')
    return tri

def get_tarp_center(vertices):
    center_pos=np.sum(vertices,axis=0)/vertices.shape[0]
    dis=np.sum((vertices-center_pos)**2,axis=1)
    return dis.argmin()

def get_tarp_mesh(vertices,faces):
    #translation
    vertices3=np.zeros((vertices.shape[0],3))
    #print(vertices3[:,0:2].shape)
    vertices3[:,0:2]=vertices[:,0:2]
    vertices3[:,2]=tarp_height
    #if center_id<0:
    center_id=get_tarp_center(vertices3)
    print('center',center_id)
    vertices3[:,0]=vertices3[:,0]-vertices3[center_id,0]
    vertices3[:,1]=vertices3[:,1]-vertices3[center_id,1]

    #scale
    """ mesh_bb=np.min(vertices3,axis=1),np.max(vertices3,axis=1)
    mesh_size=max(mesh_bb[1][0]-mesh_bb[0][0],mesh_bb[1][1]-mesh_bb[0][1]) """
    mesh_bb=np.min(vertices3[:,0],axis=0),np.max(vertices3[:,0],axis=0),\
            np.min(vertices3[:,1],axis=0),np.max(vertices3[:,1],axis=0)
    mesh_size=max(mesh_bb[1]-mesh_bb[0],mesh_bb[3]-mesh_bb[2])
    #print(mesh_bb)
    vertices3[:,0:2]=vertices3[:,0:2]*tarp_size/mesh_size

    #reverse mesh orientation if needed
    v0=vertices3[faces[0][0]]
    v1=vertices3[faces[0][1]]
    v2=vertices3[faces[0][2]]
    #if (v1-v0).cross(v2-v0).dot(tarp_ori)<0:
    if np.dot(np.cross(v1-v0,v2-v0),tarp_ori)<0:
        temp=np.copy(faces[:,1])
        faces[:,1]=faces[:,2]
        faces[:,2]=temp
    
    return vertices3,faces


def mesh(tri):
    vertices2=tri.get('vertices')
    faces=tri.get('triangles')
    vertices3=np.zeros((vertices2.shape[0],3))
    vertices3[:,0:2]=vertices2
    return pymeshlab.Mesh(vertices3,faces)
