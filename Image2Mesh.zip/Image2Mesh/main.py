import cv2
import os
import numpy as np
import triangle
import pymeshlab
import tool

pic='turtle.png'
thr=27
rate=0.001
targetlen=pymeshlab.PercentageValue(0.5)
iterations=100
black_background=0


# 读取图像
image = cv2.imread('picture/'+pic)
#if white_background:


# 转换图像为灰度
gray = cv2.cvtColor(image if black_background==1 else 255-image, cv2.COLOR_BGR2GRAY)

# 进行阈值处理
ret, thresh = cv2.threshold(gray, thr, 255, 0)

# 查找轮廓
contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

# 遍历每个轮廓
for i, contour in enumerate(contours):
    print(i)
    # 进行多边形逼近
    epsilon =rate * cv2.arcLength(contour, True)
    approx = np.array(cv2.approxPolyDP(contour, epsilon, True)[:,0,:])[::-1]
    # 输出多边形坐标
    #print(f"Polygon {i + 1} coordinates: {approx}")
    tri=tool.dt(approx)
    m=tool.mesh(tri)
    ms=pymeshlab.MeshSet()
    ms.add_mesh(m,"cube_mesh")
    
    #ms.apply_coord_laplacian_smoothing_surface_preserving()
    ms.meshing_isotropic_explicit_remeshing(targetlen=targetlen,iterations=iterations)
    #ms.save_current_mesh(file_name=os.path.join('/home/yanyisheshou/Program/Image2Mesh/meshdata',os.path.splitext(pic)[0]+'.obj'))
    vertices=ms.current_mesh().vertex_matrix()
    print('vertices num',vertices.shape[0])
    #print(vertices.shape[0])
    faces=ms.current_mesh().face_matrix()
    for f in faces: 
        pos=np.zeros((3,2))
        pos[0]=vertices[f[0],0:2]
        pos[1]=vertices[f[1],0:2]
        pos[2]=vertices[f[2],0:2]
        pos=pos.astype(np.int32)
        cv2.polylines(image,[pos],True,(0,255,0),1)
    # 在原图上绘制多边形
    #cv2.polylines(image, [line], True, (0, 255, 0), 2)
    if i>0:
        continue
    vertices,faces=tool.get_tarp_mesh(vertices,faces)
    ms.add_mesh(pymeshlab.Mesh(vertices,faces),"tarp_mesh")
    ms.save_current_mesh(file_name=os.path.join('/home/yanyisheshou/Program/Image2Mesh/meshdata',os.path.splitext(pic)[0]+'.obj'))


# 显示结果图像
cv2.imshow('Contours', image)
cv2.waitKey(0)
cv2.destroyAllWindows()