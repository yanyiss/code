#!/usr/bin/env python

import sys
import numpy as np
from PyQt5.QtCore import *
from PyQt5.QtWidgets import QApplication, QMainWindow, QOpenGLWidget, QVBoxLayout#, QWidget
from PyQt5 import uic


from OpenGL.GL import *
from OpenGL.GLU import *
import openmesh
import os

class SimulationWidget(QOpenGLWidget):
    #sign_one = pyqtSignal()
    def initializeGL(self):
        glClearColor(0.5, 1.0, 1.0, 1.0)  # Set clear color to white
        glEnable(GL_DEPTH_TEST)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(45.0, self.width() / self.height(), 0.1, 100.0)
        
        # Camera properties
        self.cam_position = np.array([0.0, -5.0, 5.0])
        self.cam_target = np.array([0.0, 0.0, 2.45])
        self.cam_up_vector = np.array([0.0, 0.0, 1.0])
        
        self.rotate_speed = 0.01
        self.move_speed = 0.05

        self.color=np.array([1,0,0])
        self.point=np.array([0.0,0.0,0.0])
        #self.sign_one.connect(self.changecolor)

        mesh=openmesh.read_trimesh(os.path.join(folder_name,'result.obj'))
        self.nv=mesh.n_vertices()
        self.nf=mesh.n_faces()
        self.vertices=np.zeros((self.nv,3))
        self.faces=np.zeros((self.nf,3)).astype(np.int32)
        for v in mesh.vertices():
            pos=mesh.point(v)
            self.vertices[v.idx(),:]=pos
        for f in mesh.faces():
            i=0
            for fv in mesh.fv(f):
                self.faces[f.idx(),i]=fv.idx()
                i=i+1
        
        self.index=np.loadtxt(os.path.join(folder_name,'index.txt'),dtype=np.int32)

        force=np.loadtxt(os.path.join(folder_name,'last_force.txt'),dtype=np.float64)
        self.forces=force.reshape(self.index.shape[0],3)
    
    def mousePressEvent(self, event):
        self.mouse_last_position = event.pos()
    
    def wheelEvent(self, event):
        delta = event.angleDelta().y() / 120  # The vertical scroll amount
        self.cam_position += (self.cam_target - self.cam_position) * self.move_speed * delta
        self.update()
        #self.sign_one.emit()

    def mouseMoveEvent(self, event):
        return
    
    def paintGL(self):
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        gluLookAt(*(list(self.cam_position) + list(self.cam_target) + list(self.cam_up_vector)))

        vertices=self.vertices
        faces=self.faces

        #draw triangle mesh
        glColor3f(1.0,1.0,0.0)
        glBegin(GL_TRIANGLES)
        for face in self.faces:
            glVertex3d(vertices[face[0]][0],vertices[face[0]][1],vertices[face[0]][2])
            glVertex3d(vertices[face[1]][0],vertices[face[1]][1],vertices[face[1]][2])
            glVertex3d(vertices[face[2]][0],vertices[face[2]][1],vertices[face[2]][2])
        glEnd() 

        glColor3f(0.0,0.0,0.0)
        glLineWidth(2)
        glBegin(GL_LINES)
        for face in self.faces:
            glVertex3f(vertices[face[0]][0],vertices[face[0]][1],vertices[face[0]][2])
            glVertex3f(vertices[face[1]][0],vertices[face[1]][1],vertices[face[1]][2])
            glVertex3f(vertices[face[2]][0],vertices[face[2]][1],vertices[face[2]][2])
            glVertex3f(vertices[face[0]][0],vertices[face[0]][1],vertices[face[0]][2])
            glVertex3f(vertices[face[1]][0],vertices[face[1]][1],vertices[face[1]][2])
            glVertex3f(vertices[face[2]][0],vertices[face[2]][1],vertices[face[2]][2])
        glEnd()

        index=self.index
        rate=0.8
        forces=self.forces*rate
        isize=index.shape[0]
        
        #draw current force
        id=0
        glLineWidth(2)
        glBegin(GL_LINES)
        #glColor3f(0.7,0.0,0.0)
        for i in index:
            # if forces[id][2]>0:
            #     glColor3f(0.7,0.0,0.0)
            # else:
            #     glColor3f(0.0,0.7,0.0)
            glColor(0.7,0.0,0.0)
            glVertex3f(vertices[i][0],vertices[i][1],vertices[i][2])
            glVertex3f(vertices[i][0]+forces[id][0],vertices[i][1]+forces[id][1],vertices[i][2]+forces[id][2])
            id=id+1
        glEnd()
        

        #draw axis
        glLineWidth(2)
        glBegin(GL_LINES)
        glColor3f(1.0,0.0,0.0)
        glVertex3f(0.0,0.0,0.0)
        glVertex3f(10.0,0.0,0.0)
        glColor3f(0.0,1.0,0.0)
        glVertex3f(0.0,0.0,0.0)
        glVertex3f(0.0,10.0,0.0)
        glColor3f(0.0,0.0,1.0)
        glVertex3f(0.0,0.0,0.0)
        glVertex3f(0.0,0.0,10.0)
        glEnd()

        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
        glFlush()

    def update_simulation(self):
        self.update()
        

    def timerEvent(self, event):
        self.update_simulation()

class MainWindow(QMainWindow):
    def __init__(self, *args, **kwargs):
        super(QMainWindow, self).__init__(*args, **kwargs)

        uic.loadUi('ClothSimulationGUI/mainwindow.ui', self)

        self.simulation_widget = SimulationWidget(self.simulationWidget)
        #self.simulation_widget.solids = []
        self.timer = QTimer()

        """ self.plane = Plane()
        self.plane.rotate([1,0,0], -90)
        self.plane.scale(8.0)
        self.plane.translate([0.0, -0.01,0.0]) """

        self.timer.timeout.connect(self.simulation_widget.update_simulation)
        
        #self.collision_object.currentTextChanged.connect(self.update_collision_object_fields)

        self.simulation_widget.setFocusPolicy(Qt.StrongFocus)
        self.simulation_widget.setFocus()

        """ self.set_values_simulation()
        self.simulation_widget.solids.append(self.plane)
        self.add_solid_check_box.toggled.connect(self.toggle_combobox)
        self.add_floor_check_box.toggled.connect(self.toggle_floor) """

        layout = QVBoxLayout(self.simulationWidget)
        layout.addWidget(self.simulation_widget)

        #self.set_cloth_default_button.clicked.connect(self.set_default)
        self.simulate_button.clicked.connect(self.start_simulation)
        self.stop_simulation_button.clicked.connect(self.stop_simulation)
        self.restart_simulation_button.clicked.connect(self.restart_simulation) 

    def mousePressEvent(self, event):
        self.simulation_widget.mousePressEvent(event)

    def mouseMoveEvent(self, event):
        return
        self.simulation_widget.mouseMoveEvent(event)
    
    def timerEvent(self, event):
        self.simulation_widget.update_simulation()

    def keyPressEvent(self, event):
        # Move the camera depending on which key is pressed
        if event.key() == Qt.Key_Escape:
            self.close()
        if event.key() == Qt.Key_W:
            self.simulation_widget.cam_position += self.simulation_widget.move_speed * self.simulation_widget.cam_up_vector
        elif event.key() == Qt.Key_S:
            self.simulation_widget.cam_position -= self.simulation_widget.move_speed * self.simulation_widget.cam_up_vector
        elif event.key() == Qt.Key_A:
            self.simulation_widget.cam_position -= np.cross(self.simulation_widget.cam_target - self.simulation_widget.cam_position, self.simulation_widget.cam_up_vector) * self.simulation_widget.move_speed
        elif event.key() == Qt.Key_D:
            self.simulation_widget.cam_position += np.cross(self.simulation_widget.cam_target - self.simulation_widget.cam_position, self.simulation_widget.cam_up_vector) * self.simulation_widget.move_speed

        self.simulation_widget.update()

    def start_simulation(self):
        timer_interval = 1
        self.timer.start(timer_interval)

    def stop_simulation(self):
        if self.timer.isActive():
            self.timer.stop()
    
    def restart_simulation(self):
        self.stop_simulation()
        self.start_simulation()

import downloader
if __name__ == "__main__":
    if 0:
        if 0: 
            remote_dir = '/home/BA22001030/program/TarpDesign'
            local_dir = '/home/yanyisheshou/Program/TarpViewer/code'
        else:
            remote_dir = '/home/BA22001030/program/BalanceSolver'
            local_dir = '/home/yanyisheshou/Program/TarpViewer/code'
        downloader.ssh_downloadercode(remote_dir,local_dir)
        exit(0)



    folder_name='2024-03-21---19-36-55-313950'

    current_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)),folder_name)

    if os.path.exists(current_dir)==True:
        os.remove(os.path.join(current_dir,'force_displace.txt'))
        #os.remove(os.path.join(current_dir,'transform_force_displace.txt'))
        os.remove(os.path.join(current_dir,'force.txt'))
        os.remove(os.path.join(current_dir,'index.txt'))
        os.remove(os.path.join(current_dir,'last_force.txt'))
        os.remove(os.path.join(current_dir,'loss.png'))
        os.remove(os.path.join(current_dir,'params.yaml'))
        os.remove(os.path.join(current_dir,'readme.txt'))
        os.remove(os.path.join(current_dir,'result.obj'))
        os.remove(os.path.join(current_dir,'time.txt'))

    downloader.ssh_downloader(folder_name)
    app = QApplication(sys.argv)
    widget = MainWindow()
    widget.show()
    sys.exit(app.exec_())
